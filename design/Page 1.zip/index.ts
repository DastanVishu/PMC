export {Frame1} from './components/Frame1';

