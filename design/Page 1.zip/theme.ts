export default {
  // No figma styles found
};
